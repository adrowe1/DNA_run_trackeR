library(jsonlite)
library(ggplot2)
library(magrittr)
library(viridis)
library(dplyr)
# the directory is talen here 
jsonfile <- "data/hOgg1_0mMNaCl_2016102605_23.5mspf_112nmpp_2-4_2000X_26850-27000.tif.json"
rawdata <- fromJSON(jsonfile) 
# inital visualization of the raw data 
plot1 <- rawdata%>%
  ggplot(aes(x=`x [nm]`, y=`y [nm]`, colour=frame)) + geom_point(alpha=0.5) + theme_bw() + coord_equal(ratio=1)
plot1

# this is for the extraction of the raw data from the data base 
rawi <- rawdata$id
rawf <- rawdata$frame
rawx <- rawdata$`x [nm]`
rawy <- rawdata$`y [nm]`
selection <- data.frame(rawi, rawf, rawx, rawy)
 
rm(rawf, rawi, rawx, rawy)
# here the limits of the x and y are given and dmax as a max displacement of the protein in one frame, dmin can be used to avoid stationary signals 

xmin=4000
xmax=7000
ymin=1500
ymax=1800
dmax=600
dmin=1
# first filtering based on input information 

filter1<- selection %>% filter(rawx>xmin, rawx<xmax, rawy>ymin, rawy<ymax)
attach(filter1)
# second filtering and rearrangement the data based on frame numbers 

c1 <- max(max(rawf), length(rawf)) # exracting the number of needed iteration for frame rearrangements  
c2 <-sum(duplicated(rawf))
c <- c1+c2-1

felx=0 # i have to introduce the initial amounts as 0 otherwise i'll see errors 
fely=0
felf=0
k=0
p=0

# the rearrangement loop 

for(i in 1:c) {
    if (rawf[i-k]-(i-p)>0){ # if there is no signal in the frame the frame number is missing in data, here it will be register with the 0 values for x and y   
      k <- k+1
      felf[i-p] <- i-p
      felx[i-p] <- 0
      fely[i-p] <- 0
    }
    else if (rawf[i-k]-(i-p) ==0){ # if there is one signal in the frame register it 
      felf[i-p] <- rawf[i-k]
      felx[i-p] <- rawx[i-k]
      fely[i-p] <- rawy[i-k]
    }
    else { # if there is more than one signal in the frame, find the one that is closer to the DNA in y    
      my <- mean(rawy[(i-k-4):(i-k-2)])
      y1 <- rawy[rawf==i-p-1]
      y2 <- abs(y1-my)
      ny <- which.min(y2)
      p <- p+1
      felx[i-p] <- rawx [i-k-2+ny]
      fely[i-p] <- rawy [i-k-2+ny]
      print(i-p)
      print(ny)
    }
}
# end of the rearrangement, results are saved in database 

filter2 <- data.frame(felf, felx, fely)  

# introduction of objects for scanning detection loop  

detx=0
dety=0
detf=0

# detection loop 
for(i in 1: (max(felf)-2)) {
    delta1 <- abs(felx[i+1]-felx[i])
    delta2 <- abs(felx[i+2]-felx[i])
  if (delta1 < dmax & delta1 > dmin) {
    detx[i] <- felx[i]
    dety[i] <- fely[i]
    detf[i] <- felf[i]
  }
  else if (delta2 < dmax & delta2 > dmin){
    detx[i] <- felx[i]
    dety[i] <- fely[i]
    detf[i] <- felf[i] 
      }
  else{
    detx[i] <- NA
    dety[i] <- NA
    detf[i] <- felf[i]
  }
  }  
# end of the detection loop, results are saved in database   

detect <- data.frame(detf, detx, dety)

# plots can be tweaked and become more practical 

# signal distribution plots can be modified such that it shows the process of filteration and detection 
selection%>%
  ggplot(aes(x=rawx, y=rawy, colour=rawf)) + geom_point(alpha=0.5) + theme_bw() + coord_equal(ratio=1)
filter2%>%
  ggplot(aes(x=felx, y=fely, colour=felf)) + geom_point(alpha=0.5) + theme_bw() + coord_equal(ratio=1)
detect%>%
  ggplot(aes(x=detx, y=dety, colour=detf)) + geom_point(alpha=0.5) + theme_bw() + coord_equal(ratio=1)


# detected trajectories:  
# showing the detected trajectory among the whole data can be interesting 
# a zoomable plot can make it easy to find the scanning reactions 
selection%>%
  ggplot(aes(x=rawf, y=rawx)) + geom_point(alpha=1)

filter2%>%
  ggplot(aes(x=felf, y=felx)) + geom_point(alpha=1)

 
detect%>%
  ggplot(aes(x=detf, y=detx)) + geom_line(alpha=1)
# coord_cartesian(xlim = c(1200,1400))      ## for zooming 
#geom_point(aes( y=felx, alpha=0.5))
#geom_point(aes( y=rawx, alpha=0.1))
  
rm(list = ls())



